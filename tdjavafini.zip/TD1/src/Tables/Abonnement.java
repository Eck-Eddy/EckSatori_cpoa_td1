package Tables;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Abonnement {
	protected Connexion connexion;
	
	public Abonnement() {
		this.connexion = connexion;
	}

	public void ajoutAbonnement(int idc,int idr, String dd,String df) { //done
		
		try {
			connexion = new Connexion();
			Connection laConnexion = connexion.creeConnexion();
			Statement requete = laConnexion.createStatement();
			int res = requete.executeUpdate(""
					+ "INSERT INTO Abonnement(id_client,id_revue,date_debut,date_fin)"
					+ "VALUES("+idc+","+idr+",'"+dd+"','"+df+"')");
			laConnexion.close();
			 
		}
		catch (SQLException sqle) {
			System.out.println("Pb select" + sqle.getMessage());
		}
	}
	
	public void modifAbonnement(int idc,int idr, String dd,String df) {
		
		try {
			connexion = new Connexion();
			Connection laConnexion = connexion.creeConnexion();
			Statement requete = laConnexion.createStatement();
			int res = requete.executeUpdate(""
					+ "UPDATE Abonnement SET date_debut = '" +dd+ "', date_fin = '"+df+"' WHERE id_client ="+idc+" AND id_revue="+idr);
			laConnexion.close();

			 
		}
		catch (SQLException sqle) {
			System.out.println("Pb select" + sqle.getMessage());
		}
	}
	public void supprAbonnement(int idc, int idr) {
		
		try {
			connexion = new Connexion();
			Connection laConnexion = connexion.creeConnexion();
			Statement requete = laConnexion.createStatement();
			int res = requete.executeUpdate("DELETE FROM Abonnement WHERE id_client = "+idc+" AND id_revue="+idr);
			laConnexion.close();

			 
		}
		catch (SQLException sqle) {
			System.out.println("Pb select" + sqle.getMessage());
		}
	}
}
