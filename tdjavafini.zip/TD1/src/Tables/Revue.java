package Tables;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Revue {
	protected Connexion connexion;
	
	public Revue() {
		this.connexion = connexion;
	}

	public void ajoutRevue(String t,String d, double tn,String v, int id) { //done
		
		try {
			connexion = new Connexion();
			Connection laConnexion = connexion.creeConnexion();
			Statement requete = laConnexion.createStatement();
			int res = requete.executeUpdate(""
					+ "INSERT INTO Revue(titre,description,tarif_numero,visuel,id_periodicite)"
					+ "VALUES('"+t+"','"+d+"',"+tn+",'"+v+"',"+id+")");
			laConnexion.close();
			 
		}
		catch (SQLException sqle) {
			System.out.println("Pb select" + sqle.getMessage());
		}
	}
	
	public void modifRevue(int id,String nt, String nd, double ntn, String nv,int nid) {
		
		try {
			connexion = new Connexion();
			Connection laConnexion = connexion.creeConnexion();
			Statement requete = laConnexion.createStatement();
			int res = requete.executeUpdate(""
					+ "UPDATE Revue SET titre = '" +nt+ "', description = '"+nd+"',tarif_numero="+ntn+",visuel='"+nv+"',id_periodicite="+nid+" WHERE id_revue ="+id);
			laConnexion.close();

			 
		}
		catch (SQLException sqle) {
			System.out.println("Pb select" + sqle.getMessage());
		}
	}
	public void supprRevue(int id) {
		
		try {
			connexion = new Connexion();
			Connection laConnexion = connexion.creeConnexion();
			Statement requete = laConnexion.createStatement();
			int res = requete.executeUpdate("DELETE FROM Revue WHERE id_revue = "+id+"");
			laConnexion.close();

			 
		}
		catch (SQLException sqle) {
			System.out.println("Pb select" + sqle.getMessage());
		}
	}
}
