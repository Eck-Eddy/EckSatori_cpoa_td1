package Tables;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Client {
	protected Connexion connexion;
	
	public Client() {
		this.connexion = connexion;
	}

public void ajoutClient(int id, String nom,String prenom, String nrue, String voie, String cp, String ville, String pays) { //done
		
		try {
			connexion = new Connexion();
			Connection laConnexion = connexion.creeConnexion();
			Statement requete = laConnexion.createStatement();
			int res = requete.executeUpdate(""
					+ "INSERT INTO Client(id_client,nom,prenom,no_rue,voie,code_postal,ville,pays)"
					+ "VALUES("+id+",'"+nom+"','"+prenom+"','"+nrue+"','"+voie+"','"+cp+"','"+ville+"','"+pays+"')");
			laConnexion.close();
			 
		}
		catch (SQLException sqle) {
			System.out.println("Pb select" + sqle.getMessage());
		}
	}
	
	public void modifClient(int id, String nom,String prenom, String nrue, String voie, String cp, String ville, String pays) {
		
		try {
			connexion = new Connexion();
			Connection laConnexion = connexion.creeConnexion();
			Statement requete = laConnexion.createStatement();
			int res = requete.executeUpdate(""
					+ "UPDATE Client SET nom = '"+nom+"', prenom = '"+prenom+"',no_rue = '"+nrue+"', voie = '"+voie+"', code_postal = '"+cp+"', ville = '"+ville+"', pays = '"+pays+"', id_client = "+id+" WHERE id_client ="+id);
			laConnexion.close();

			 
		}
		catch (SQLException sqle) {
			System.out.println("Pb select" + sqle.getMessage());
		}
	}
	public void supprClient(int id) {
		
		try {
			connexion = new Connexion();
			Connection laConnexion = connexion.creeConnexion();
			Statement requete = laConnexion.createStatement();
			int res = requete.executeUpdate("DELETE FROM Client WHERE id_client = "+id);
			laConnexion.close();

			 
		}
		catch (SQLException sqle) {
			System.out.println("Pb select" + sqle.getMessage());
		}
	}
}
